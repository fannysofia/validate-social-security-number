import React from "react";
import Validate1 from "./Validate1";
import Validate2 from "./Validate2";
import Validate4 from "./Validate4";
import Validate5 from "./Validate5";
import Validate6 from "./Validate6";
import Validate3 from "./Validate3";
const Lesson2 = props => {
  return (
    <div>
      <h1>Form</h1>
      <Validate5 />
    </div>
  );
};

export default Lesson2;
