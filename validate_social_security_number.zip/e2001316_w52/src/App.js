import React from "react";
import logo from "./logo.svg";
import "./App.css";
import Lesson2 from "./components/lesson2/Lesson2";

function App() {
  return (
    <div>
      <Lesson2 />
    </div>
  );
}

export default App;

